# My First Project > 2025-03-21 11:04pm
https://universe.roboflow.com/melvins/my-first-project-w0n2j

Provided by a Roboflow user
License: CC BY 4.0

